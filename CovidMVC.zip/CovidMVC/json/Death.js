﻿$(function () {
    $("#btnPost5").click(function () {
        //var customer = new Object();
        //customer.Customer_Name = $('#txtName').val();
        //customer.Customer_Mobilenumber = $('#txtMobile').val();
        //customer.Customer_Email = $('#txtEmail').val();
        //customer.Customer_Password = $('#txtPassword').val();
        //customer.Customer_Confirm_Password = $('#txtCofrmPassword').val();
        //customer.Customer_Address = $('#txtAddress').val();
        var obj = new Object();
        obj.Member_Name = $('#txtname5').val();
        obj.Aadhar = $('#txtadhar5').val();
        obj.Mobile_Number = $('#txtNum5').val();
        obj.Death_date = $('#date3').val();


        if (obj != null) {
            $.ajax({
                type: "POST",
                url: "/Index/Insert_Death",
                data: JSON.stringify(obj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response > 0) {
                        alert("Submitted Successfull");
                    } else {
                        alert("Fill the Fields correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});
