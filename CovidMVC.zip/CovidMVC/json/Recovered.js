﻿$(function () {
    $("#btnPost3").click(function () {
        //var customer = new Object();
        //customer.Customer_Name = $('#txtName').val();
        //customer.Customer_Mobilenumber = $('#txtMobile').val();
        //customer.Customer_Email = $('#txtEmail').val();
        //customer.Customer_Password = $('#txtPassword').val();
        //customer.Customer_Confirm_Password = $('#txtCofrmPassword').val();
        //customer.Customer_Address = $('#txtAddress').val();
        var obj = new Object();
        obj.Member_Name = $('#txtname3').val();
        obj.Aadhar = $('#txtadhar3').val();
        obj.Mobile_Number = $('#txtNum3').val();
        obj.Recovery_date = $('#date1').val();



        if (obj != null) {
            $.ajax({
                type: "POST",
                url: "/Index/Insert_Recovered",
                data: JSON.stringify(obj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response > 0) {
                        alert("Submitted Successfull");
                    } else {
                        alert("Fill all Fields Correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});
