﻿$(function () {
    $("#btnPost4").click(function () {
        //var customer = new Object();
        //customer.Customer_Name = $('#txtName').val();
        //customer.Customer_Mobilenumber = $('#txtMobile').val();
        //customer.Customer_Email = $('#txtEmail').val();
        //customer.Customer_Password = $('#txtPassword').val();
        //customer.Customer_Confirm_Password = $('#txtCofrmPassword').val();
        //customer.Customer_Address = $('#txtAddress').val();
        var obj = new Object();
        obj.Member_Name = $('#txtname4').val();
        obj.Aadhar = $('#txtadhar4').val();
        obj.Mobile_Number = $('#txtNum4').val();
        obj.Vaccination_date = $('#date2').val();



        if (obj != null) {
            $.ajax({
                type: "POST",
                url: "/Index/Insert_Vaccine",
                data: JSON.stringify(obj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response > 0) {
                        alert("Submitted Successfull");
                    } else {
                        alert("Fill all Fields Correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});
