﻿        $(document).ready(function () {
            $("#btnPost2").click(function () {
                var SearchBy = $("#SearchBy").val();
                console.log('my message' + SearchBy);
                var SearchValue = $("#Search").val();
                console.log('my message' + SearchValue);
                var SetData = $("#DataSearching");
                SetData.html("");
                $.ajax({
                    type: "post",
                    url: "/Index/=" + SearchBy + "&SearchValue=" + SearchValue,
                    contentType: "html",
                    success: function (result) {
                        console.log('my message' + result);
                        if (result.length == 0) {
                            SetData.append('<tr style="color:red"><td colspan="3">No Data Found</td></tr>')
                        }
                        else {
                            $.each(result, function (index, value) {
                                var Data = "<tr>" +
                                    "<td>" + value.id + "</td>" +
                                    "<td>" + value.h_name + "</td>" +
                                    "<td>" + value.h_type + "</td>" +
                                    "<td>" + value.h_area + "</td>" +
                                    "<td>" + value.h_city + "</td>" +
                                    "<td>" + value.h_address + "</td>" +
                                    "<td>" + value.mobileNumber + "</td>" +
                                    "<td>" + value.h_email + "</td>" +
                                    "</tr>";
                                SetData.append(Data);
                            });
                        }
                    }
                });
            });
        });
</script>