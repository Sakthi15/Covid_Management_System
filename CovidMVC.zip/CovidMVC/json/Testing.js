﻿$(function () {
    $("#btnPost").click(function () {
        //var customer = new Object();
        //customer.Customer_Name = $('#txtName').val();
        //customer.Customer_Mobilenumber = $('#txtMobile').val();
        //customer.Customer_Email = $('#txtEmail').val();
        //customer.Customer_Password = $('#txtPassword').val();
        //customer.Customer_Confirm_Password = $('#txtCofrmPassword').val();
        //customer.Customer_Address = $('#txtAddress').val();
        var obj = new Object();
        obj.Member_Name = $('#txtname').val();
        obj.Age = Number($('#txtage').val());
        obj.Aadhar_Number = $('#txtadhar').val();
        obj.Contact_Number = $('#txtNum').val();
        obj.Gender = $('#txtgender').val();
        obj.Address = $('#txtadd').val();


        if (obj != null) {
            $.ajax({
                type: "POST",
                url: "/Index/Insert_testing",
                data: JSON.stringify(obj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response > 0) {
                        alert("Registration Successfull");
                    } else {
                        alert("Fill all Fields Correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});
