﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CovidMVC.Models;

namespace CovidMVC.Controllers
{
    public class IndexController : Controller
    {
        CovidProjectEntities2 cov = new CovidProjectEntities2();
        // GET: Index
        public ActionResult index()
        {
            return View();
        }
        public ActionResult Testing()
        {
            return View(cov.Testings.ToList());
        }
        [HttpPost]
        public JsonResult Insert_testing(Testing test)
        {
            Nullable<int> obj = 0;
            string member_Name = test.Member_Name;
            int age = test.Age;
            string aadhar_Number = test.Aadhar_Number;
            string gender = test.Gender;
            string address = test.Address;
            string contact_Number = test.Contact_Number;
            if(ModelState.IsValid)
            obj = cov.Insert_Testing(member_Name, age, aadhar_Number, contact_Number, gender, address);

            /*Session["Username"] = username;*///session created } return Json(result, JsonRequestBehavior.AllowGet); }
                                               //string username = logindetails.UserName; string password = logindetails.Password;
                                               //USP_CheckUser(username, password).FirstOrDefault(); int result = obj.Value; if (result > 0)
            int result1 = obj.Value;
            return Json(result1, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Effected()
        {
            return View(cov.Effecteds.ToList());
        }
        [HttpPost]
        public JsonResult Insert_Effected(Effected eff)
        {
            Nullable<int> obj = 0;
            string member_Name = eff.Member_Name;
            string aadhar_Number = eff.Aadhar;
            string contact_Number = eff.Mobile_Number;
            string eff_date = eff.Effected_date;
            if(ModelState.IsValid)
            obj=cov.Insert_Effected(member_Name, aadhar_Number, contact_Number, eff_date);

            /*Session["Username"] = username;*///session created } return Json(result, JsonRequestBehavior.AllowGet); }
                                               //string username = logindetails.UserName; string password = logindetails.Password;
                                               //USP_CheckUser(username, password).FirstOrDefault(); int result = obj.Value; if (result > 0)
            int result1 = obj.Value;
            return Json(result1, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Recovered()
        {
            return View(cov.Recovereds.ToList());
        }
        [HttpPost]
        public JsonResult Insert_Recovered(Recovered rec)
        {
            Nullable<int> obj = 0;
            string member_Name = rec.Member_Name;
            string aadhar_Number = rec.Aadhar;
            string contact_Number = rec.Mobile_Number;
            string rec_date = rec.Recovery_date;
            if(ModelState.IsValid)
            obj= cov.Insert_Recovered(member_Name, aadhar_Number, contact_Number, rec_date);

            /*Session["Username"] = username;*///session created } return Json(result, JsonRequestBehavior.AllowGet); }
                                               //string username = logindetails.UserName; string password = logindetails.Password;
                                               //USP_CheckUser(username, password).FirstOrDefault(); int result = obj.Value; if (result > 0)
            int result1 = obj.Value;
            return Json(result1, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Vaccination()
        {
            return View(cov.Registration_Vaccine.ToList());
        }
        [HttpPost]
        public JsonResult Insert_Registration(Registration_Vaccine res)
        {
            Nullable<int> obj = 0;
           string member_Name = res.Member_Name;
            int age = res.Age;
            string aadhar_Number = res.Aadhar_Number;
            string gender = res.Gender;
            string address = res.Address;
            string contact_Number = res.Mobile_Number;
            string vaccine = res.Vaccine_Name;
            if(ModelState.IsValid)
            obj=cov.Insert_Registration_Vaccine(member_Name,age,aadhar_Number,contact_Number,gender,vaccine,address);

            /*Session["Username"] = username;*///session created } return Json(result, JsonRequestBehavior.AllowGet); }
                                               //string username = logindetails.UserName; string password = logindetails.Password;
                                               //USP_CheckUser(username, password).FirstOrDefault(); int result = obj.Value; if (result > 0)
            int result1 = obj.Value;
            return Json(result1, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Vaccinated_Members()
        {
            return View(cov.Vaccinations.ToList());
        }
        [HttpPost]
        public JsonResult Insert_Vaccine(Vaccination vac)
        {
            Nullable<int> obj = 0;
           string member_Name = vac.Member_Name;
            string aadhar_Number = vac.Aadhar;
            string contact_Number = vac.Mobile_Number;
            string vac_date = vac.Vaccination_date;
            if(ModelState.IsValid)
            obj=cov.Insert_Vaccine(member_Name, aadhar_Number, contact_Number, vac_date);

            /*Session["Username"] = username;*///session created } return Json(result, JsonRequestBehavior.AllowGet); }
                                               //string username = logindetails.UserName; string password = logindetails.Password;
                                               //USP_CheckUser(username, password).FirstOrDefault(); int result = obj.Value; if (result > 0)
            int result1 = obj.Value;
            return Json(result1, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Deaths()
        {
            return View(cov.Deaths.ToList());
        }
        [HttpPost]
        public JsonResult Insert_Death(Death dead)
        {
            Nullable<int> obj = 0;
            string member_Name = dead.Member_Name;
            string aadhar_Number = dead.Aadhar;
            string contact_Number = dead.Mobile_Number;
            string dead_date = dead.Death_date;
            if(ModelState.IsValid)
            obj= cov.Insert_Death(member_Name, aadhar_Number, contact_Number, dead_date);

            /*Session["Username"] = username;*///session created } return Json(result, JsonRequestBehavior.AllowGet); }
                                               //string username = logindetails.UserName; string password = logindetails.Password;
                                               //USP_CheckUser(username, password).FirstOrDefault(); int result = obj.Value; if (result > 0)
            int result1 = obj.Value;
            return Json(result1, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Death()
        {
            return View();
        }

    }
}